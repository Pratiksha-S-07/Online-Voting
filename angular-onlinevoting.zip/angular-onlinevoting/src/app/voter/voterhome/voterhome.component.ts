import { Component } from '@angular/core';

@Component({
  selector: 'app-voterhome',
  templateUrl: './voterhome.component.html',
  styleUrls: ['./voterhome.component.css']
})
export class VoterhomeComponent {

}
